<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
 $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
 $routes->get('/', 'Home::index');
 //Usuarios
 $routes->post('Usuarios/Autenticar', 'Usuarios::Autenticar');
 $routes->post('Usuarios/Usuario', 'Usuarios::Usuario');
 $routes->post('Usuarios/Usuario', 'Usuarios::Usuario');
 $routes->post('Usuarios/UsuarioAngular', 'Usuarios::UsuarioAngular');
 $routes->post('Usuarios/ActualizarFotoPerfil', 'Usuarios::ActualizarFotoPerfil');
 $routes->post('Usuarios/Usuarioxid', 'Usuarios::Usuarioxid');
 $routes->post('Usuarios/ObtenerUsuarios', 'Usuarios::ObtenerUsuarios');
 $routes->post('Usuarios/ObtenerUsuariosNumeros', 'Usuarios::ObtenerUsuariosNumeros');
 $routes->post('Usuarios/CambiarStatusUsuarios', 'Usuarios::CambiarStatusUsuarios');
 $routes->get('Usuarios/CatGasolineras', 'Usuarios::CatGasolineras');
 $routes->get('Usuarios/Perfiles', 'Usuarios::Perfiles');
 $routes->resource('Usuarios');

//Clientes
$routes->post('Clientes/obtenerClientes', 'Clientes::obtenerClientes');
$routes->post('Clientes/obtenerNumeroClientes', 'Clientes::obtenerNumeroClientes');
$routes->post('Clientes/obtenerClientexId', 'Clientes::obtenerClientexId');
$routes->post('Clientes/cambiarEstatus', 'Clientes::cambiarEstatus');
$routes->post('Clientes/actualizarCliente', 'Clientes::actualizarCliente');
$routes->post('Clientes/deleteClientes', 'Clientes::deleteClientes');
$routes->post('Clientes/crearcliente', 'Clientes::crearcliente');
$routes->post('Clientes/obtenerpaises', 'Clientes::obtenerpaises');
$routes->post('Clientes/aceptarFlujo', 'Clientes::aceptarFlujo');
$routes->resource('Clientes');

 //Ventas
 $routes->post('Ventas/obtenerVentas', 'Ventas::obtenerVentas');
 $routes->post('Ventas/obtenerNumeroVentas', 'Ventas::obtenerNumeroVentas');
 $routes->post('Ventas/obtenerproductos', 'Ventas::obtenerproductos');
 $routes->post('Ventas/obtenerNumeroProductos', 'Ventas::obtenerNumeroProductos');
 $routes->post('Ventas/SumaTotaProducto', 'Ventas::SumaTotaProducto');
 $routes->post('Ventas/obtenerVentaxId', 'Ventas::obtenerVentaxId');
 $routes->post('Ventas/deleteVenta', 'Ventas::deleteVenta');
 $routes->post('Ventas/obtenerlinkpago', 'Ventas::obtenerlinkpago');
 $routes->post('Ventas/crearventa', 'Ventas::crearventa');
 $routes->post('Ventas/pagoexitoso', 'Ventas::pagoexitoso');
 $routes->post('Ventas/pagofallido', 'Ventas::pagofallido');
 $routes->post('Ventas/pagopendiente', 'Ventas::pagopendiente');
 $routes->post('Ventas/crearventaTransferencia', 'Ventas::crearventaTransferencia');
 $routes->post('Ventas/obtenerProductosCompradosxCliente', 'Ventas::obtenerProductosCompradosxCliente');
 $routes->post('Ventas/cambiarEstatusCompra', 'Ventas::cambiarEstatusCompra');
 $routes->post('Ventas/tieneComprasAnteriores', 'Ventas::tieneComprasAnteriores');
 $routes->post('Ventas/negarFlujo', 'Ventas::negarFlujo');
 $routes->resource('Ventas');

 /*
 
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
